var http = require('http')
, fs = require('fs')
, url = require('url')

http.createServer(function(request, response) {
    var q = url.parse(request.url, true)
    var filename = "."+q.pathname
    console.log(filename)
    if(filename.indexOf('.html') != -1) {
        fs.readFile(filename, function(error, data) {

            if(error) {
                response.writeHead(404)
                response.write("file not found")
            } else {
                response.writeHead(200, {'Content-Type': 'text/html'})
                response.write(data)
            }
            response.end()
        })
    }
    if(filename.indexOf('.css') != -1) {
        fs.readFile(filename, function(error, data) {

            if(error) {
                response.writeHead(404)
                response.write("file not found")
            } else {
                response.writeHead(200,{'Content-Type': 'text/css'})
                response.write(data)
            }
            response.end()
        })
    }
}).listen(9000)