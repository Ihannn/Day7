import { useDispatch, useSelector } from "react-redux";
import { fetchData } from "./store/actions/fetchData";
import axios from "axios";
import { useEffect } from "react";

function App() {
  const dispatch = useDispatch(); // Dispatch digunakan untuk memanggil action
  const data = useSelector((state) => state.data); // useSelector digunakan untuk memperoleh state dari redux

  async function asyncFetchData() {
    try {
      const response = await axios.get("url"); // Untuk memperoleh data dari API
      dispatch(fetchData(response)); // Memanggil action redux dengan memberikan data yang diperoleh dari API
    } catch (err) {
      console.log(err);
    }
  }

  async function asyncDeleteData(index) {
    try {
      await axios.put("url"); // Untuk memperoleh data dari API
      asyncFetchData(); // Memanggil function fetch untuk refetch data pada API
    } catch (err) {
      console.log(err);
    }
  }

  useEffect(() => {
    asyncFetchData();
  }, []);

  return <div className="App"></div>;
}

export default App;
