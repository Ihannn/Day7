// IntialState merupakan state awal yang akan state awal pada redux
const initialState = {
  data: [],
};

export default (state = initialState, action) => {
  switch (action.type) {
    // Merupakan reducer yang akan menerima data payload dari action
    // Untuk kemudian disimpan pada state redux
    case "FETCH_DATA":
      return {
        ...state,
        data: action.payload,
      };
    default:
      return state;
  }
};
