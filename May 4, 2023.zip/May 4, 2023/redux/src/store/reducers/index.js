import { combineReducers } from "redux";
import fetchDataReducer from "./fetchData";

// Menggabungkan semua fetchReducers pada satu combineReducers sehingga setiap fetchReducers
// tidak perlu untuk dipanggil secara satu per satu, melainkan dapat dipanggil dengan cara
// hanya memanggil combine reducers yang mewakilinya.
const indexReducer = combineReducers({
  fetchData: fetchDataReducer,
});

export default indexReducer;
