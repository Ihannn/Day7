// Action yang akan dipanggil pada component
// Action ini akan memanggil reducer yang akan mengeksekusi state management pada redux
// dengan mengirim payload yang merupakan data yang diterimanya
export const fetchData = (data) => {
  return {
    type: "FETCH_DATA",
    payload: data,
  };
};
