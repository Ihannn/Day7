import { createStore } from "redux";
import rootReducer from "./reducers/index";

// Membuat redux store yang merupakan penampung state dan memungkinkan untuk melakukan dispatch action
// untuk merubah state
const configureStore = () => {
  return {
    ...createStore(rootReducer),
  };
};

export default configureStore;
